from django.db.models import Q
from rest_framework.views import APIView
from rest_framework import viewsets, status
from rest_framework.authtoken.models import Token
from rest_framework.response import Response

from .serializers import RegisterUsersSerializer, UsersSerializer
from chat.models import OneToOneMessage,OneToOneGroup
from chat.api.serializers import OneToOneGroupSerializer


class RegisterView(APIView):
    def post(self, request, format=None):
        serializer = RegisterUsersSerializer(data=request.data)
        data = {}
        if serializer.is_valid():
            user = serializer.save()
            data['username'] = user.username
            data['email'] = user.email
            token, create = Token.objects.get_or_create(user=user)
            data['token'] = token.key
        else:
            data = serializer.errors
        return Response(data)


class UsersViewSet(viewsets.ViewSet):
    serializer_class = UsersSerializer

    def list(self, request):
        queryset = OneToOneGroup.objects.filter(Q(sender=self.request.user)|Q(receiver=self.request.user))
        serializer = OneToOneGroupSerializer(queryset, many=True)
        return Response(data=serializer.data,  status=status.HTTP_404_NOT_FOUND)
