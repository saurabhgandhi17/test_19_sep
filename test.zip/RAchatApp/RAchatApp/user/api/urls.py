from rest_framework.routers import SimpleRouter,DefaultRouter
from django.urls import path
from rest_framework.authtoken.views import obtain_auth_token

from user.api import views
# from .views import UserViewSet

app_name = "user_api"

router = DefaultRouter()
router.register("users", views.UsersViewSet,basename="user")

urlpatterns = [
    path('register/', views.RegisterView.as_view(),name='register'),
    path('login/', obtain_auth_token,name='login'),
]

urlpatterns += router.urls
