import os
from channels.auth import AuthMiddlewareStack
from channels.routing import ProtocolTypeRouter,URLRouter
from django.core.asgi import get_asgi_application

from . import routing
from token_authentication import CustomTokenAuthMiddleware

# os.environ.setdefault('DJANGO_SETTINGS_MODULE','chat.settings')
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "RAchatApp.settings.dev")
django_asgi_app = get_asgi_application()
application = ProtocolTypeRouter({
    'http': get_asgi_application(),
    'websocket': CustomTokenAuthMiddleware(
        AuthMiddlewareStack(
            URLRouter(routing.websocket_urlpatterns)
        )
    )
})