import pytest
import json
import asyncio
from django.test import TestCase
from django.urls import path, reverse
from channels.routing import URLRouter
from channels.testing import WebsocketCommunicator
from rest_framework.test import APITestCase
from rest_framework import status

from .consumers import CustomWebsocketConsumer
from .models import User,OneToOneGroup,OneToOneMessage,GroupInfo,GroupMessage


@pytest.mark.django_db
@pytest.mark.asyncio
class TestWebSockets(TestCase):
    databases = '__all__'

    def setUp(self):
        self.user = User(username="saurabh")
        self.user.set_password('password@123')
        self.user.is_superuser = False
        self.user.is_staff = False
        self.user.save()

        self.user = User(username="tejash")
        self.user.set_password('password@123')
        self.user.is_superuser = False
        self.user.is_staff = False
        self.user.save()

        self.user = User(username="amit")
        self.user.set_password('password@123')
        self.user.is_superuser = False
        self.user.is_staff = False
        self.user.save()


    async def test_connect(self):
        application = URLRouter([path('ws/wsc/<str:groupname>/', CustomWebsocketConsumer.as_asgi()), ])
        communicator = WebsocketCommunicator(application, "/ws/wsc/tejash/")
        connected = await communicator.connect()
        self.assertTrue(connected)
        await communicator.disconnect()


    async def test_private_chat(self):
        application = URLRouter([path('ws/wsc/<str:groupname>/', CustomWebsocketConsumer.as_asgi()), ])
        communicator = WebsocketCommunicator(application, "/ws/wsc/tejash/")
        connected = await communicator.connect()
        self.assertTrue(connected)
        # Send data to server for testing
        await communicator.send_to(text_data=json.dumps({"msg": "hello", "message_type": "private"}))
        # check if it raise the TimeoutError or not
        if pytest.raises(asyncio.TimeoutError):
            await communicator.receive_from()
        else:
            await communicator.receive_from()
        await communicator.disconnect()


    async def test_group_chat(self):
        application = URLRouter([path('ws/wsc/<str:groupname>/', CustomWebsocketConsumer.as_asgi()), ])
        communicator = WebsocketCommunicator(application, "/ws/wsc/indian/")
        connected = await communicator.connect()
        self.assertTrue(connected)
        # Send data to server for testing
        await communicator.send_to(text_data=json.dumps({"msg": "hello", "participants": [1, 2, 3], "message_type": "group"}))
        # check if it raise the TimeoutError or not
        if pytest.raises(asyncio.TimeoutError):
            await communicator.receive_from()
        else:
            await communicator.receive_from()
        await communicator.disconnect()


@pytest.mark.django_db
@pytest.mark.asyncio
class TestEndPoints(APITestCase):
    databases = '__all__'

    def setUp(self):
        # add test users
        self.user = User(username="saurabh")
        self.user.set_password('password@123')
        self.user.is_superuser = False
        self.user.is_staff = False
        self.user.save()

        self.user = User(username="tejash")
        self.user.set_password('password@123')
        self.user.is_superuser = False
        self.user.is_staff = False
        self.user.save()

        self.user = User(username="amit")
        self.user.set_password('password@123')
        self.user.is_superuser = False
        self.user.is_staff = False
        self.user.save()


    def test_get_all_users(self):
        response = self.client.get(reverse("message_api:users-list"))
        self.assertEquals(status.HTTP_200_OK, response.status_code)


    def test_get_all_private_messageas(self):
        sender = User.objects.get(username="saurabh")
        receiver = User.objects.get(username="tejash")
        # add test messages
        private_chat = PrivateMessagesModel(content="Hello",sender=sender,receiver = receiver)
        private_chat.save()
        response = self.client.get(reverse("message_api:messages-list"))
        self.assertEquals(status.HTTP_200_OK, response.status_code)


    def test_get_all_group_messageas(self):
        # add test messages
        admin = User.objects.get(username="saurabh")
        group = GroupInfoModel(name="indian",created_by=admin)
        group.save()

        sender = User.objects.get(username="saurabh")
        participants = [1,2,3] #its dummay id for testing
        for participant in participants:
            receiver = User.objects.get(pk=participant)
            chat = GroupMessagesModel(
                content="Hello",
                sender = sender,
                participants = receiver,
                group = group
            )        
            chat.save()
        response = self.client.get(reverse("message_api:groups-list"))
        self.assertEquals(status.HTTP_200_OK, response.status_code)