from rest_framework.routers import SimpleRouter
from django.urls import path

from . import views

app_name = "user_api"

router = SimpleRouter()

urlpatterns = [
    path('messages/', views.OneToOneMessagesListAPIView.as_view(),name='messages_list'),
    path('messages/<str:pk>/', views.OneToOneMessagesDetailAPIView.as_view(),name='messages_details'),
    path('file/', views.AttachmentsView.as_view(), name='file'),
    path('groups/', views.GroupInfoView.as_view(), name='groups'),
    path('groups_messages/', views.GroupMessageView.as_view(), name='groups_messages'),
]

urlpatterns += router.urls
